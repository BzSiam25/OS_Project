import java.io.*;
import java.net.*;
import java.util.Date;

public class Server {
    public static void main(String[] args) throws IOException {
        try (ServerSocket serverSocket = new ServerSocket(9090)) {
            System.out.println("Server started and waiting for clients...");

            while (true) {
                Socket clientSocket = serverSocket.accept();  // Accept client connections
                new Thread(new ClientHandler(clientSocket)).start();  // Handle each client in a new thread
            }
        }
    }
}

class ClientHandler implements Runnable {
    private final Socket clientSocket;

    public ClientHandler(Socket socket) {
        this.clientSocket = socket;
    }

    @Override
    public void run() {
        try {
            try (clientSocket) {
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                InetAddress clientIP = clientSocket.getInetAddress();  // Get client IP
                long startTime = System.currentTimeMillis();
                in.readLine();  // Wait for ping from client
                long latency = System.currentTimeMillis() - startTime;  // Measure latency
                Date date = new Date();  // Get current server time
                // Send details to the client
                out.println("Client IP: " + clientIP.getHostAddress());
                out.println("Server Date/Time: " + date.toString());
                out.println("Ping: " + latency + " ms");
                // Close the connection
            }
        } catch (IOException e) {
        }
    }
}